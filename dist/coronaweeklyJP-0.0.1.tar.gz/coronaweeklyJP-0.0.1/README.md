# corona-weekly-JP

This package displays the rate of increase in corona cases in Japanese prefectures.

## Example of use

```
$ pip install coronaweeklyJP
$ coronaweeklyJP Hokkaido
```

Usage: coronaweeklyJP Prefecture

Positional arguments:
- Prefecture: Japanese prefecture name in English<br>
  (e.g. Hokkaido, Tokyo, Osaka, Okinawa etc.)

**Output**
![image](result.png)